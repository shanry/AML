fprintf('Adding directories to path.\n');
addpath(pwd);
cd mexfunctions
addpath(pwd);
cd ..
cd helperfunctions
addpath(pwd);
cd ..
